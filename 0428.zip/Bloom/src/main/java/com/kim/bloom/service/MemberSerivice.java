package com.kim.bloom.service;

import com.kim.bloom.model.MemberVO;

public interface MemberSerivice {

	public void memberJoin(MemberVO member) throws Exception;
	
}
